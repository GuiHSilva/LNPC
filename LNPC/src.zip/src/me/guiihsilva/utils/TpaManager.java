package me.guiihsilva.utils;

import java.util.HashMap;

import org.bukkit.entity.Player;

public class TpaManager {

	public static HashMap<Player, String> tpastatus = new HashMap<>();
	
}
